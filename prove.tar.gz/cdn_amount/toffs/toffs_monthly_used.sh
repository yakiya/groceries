#!/bin/bash
#Project: Toffs Monthly used v1.2
#Author: Xavi

#===== 固定参数 ======
monthly=`date "+%Y-%m-%d %H:%M:%S"`
EMAIL=b2@iv66.net
TOKEN=b38ddc9d5202143e606e5778542d4130
URL=https://api.toffstech.com/v1/
TTL_AMT=16000
dir='./files'

mkdir -p ./files
> $dir/padamt.txt
> $dir/usdamt.txt
> $dir/final.txt

#===== GET_PAD_IDs =====
clear

echo "=========== 已收到您的请求,请稍后 ============="

PAGE_TTL=`curl -sX GET ''{$URL}'pads/12?page=1&per_page=50' -H 'X-Auth-Email: '${EMAIL}'' -H 'X-Auth-Token: '${TOKEN}'' | jq . | grep 'total_pages_count' | sed -E 's/"|:|,/ /g' | awk '{print $2}'`
PAGE_TTL1=`curl -sX GET ''{$URL}'pads/175?page=1&per_page=50' -H 'X-Auth-Email: '${EMAIL}'' -H 'X-Auth-Token: '${TOKEN}'' | jq . | grep 'total_pages_count' | sed -E 's/"|:|,/ /g' | awk '{print $2}'`

<< amtused
PAGE_TTL=`curl -sX GET ''{$URL}'pads/12?page=1&per_page=50' -H 'X-Auth-Email: '${EMAIL}'' -H 'X-Auth-Token: '${TOKEN}'' | jq . | grep 'total_pages_count' | sed -E 's/"|:|,/ /g' | awk '{print $2}' >> $dir/usdamt.txt`
PAGE_TTL1=`curl -sX GET ''{$URL}'pads/175?page=1&per_page=50' -H 'X-Auth-Email: '${EMAIL}'' -H 'X-Auth-Token: '${TOKEN}'' | jq . | grep 'total_pages_count' | sed -E 's/"|:|,/ /g' | awk '{print $2}' >> $dir/usdamt.txt`
TTL_AMT=`cat $dir/usdamt.txt |  awk '{sum+=$1} END {print sum}'`
amtused

PAGE=1
while [ $PAGE -le $PAGE_TTL ]
#do echo > /dev/null 2>&1 ; curl -sX GET ''{$URL}'pads/12?page='${PAGE}'&per_page=50' -H 'X-Auth-Email: '${EMAIL}'' -H 'X-Auth-Token: '${TOKEN}'' | jq . | grep 'pad_name'| sed -E 's/"|:|,/ /g' | awk '{print $2}'  >> ./test.txt ; let PAGE+=1 ; done
do echo > /dev/null 2>&1; curl -sX GET ''{$URL}'pads/12?page='${PAGE}'&per_page=50' -H 'X-Auth-Email: '${EMAIL}'' -H 'X-Auth-Token: '${TOKEN}'' | jq . | grep 'customer_brand'| sed -E 's/"|:|,/ /g' | awk '{print $2}' >> $dir/padamt.txt  ; let PAGE+=1 ; done &

PAGE1=1
while [ $PAGE1 -le $PAGE_TTL1 ]
#do echo > /dev/null 2>&1 ; curl -sX GET ''{$URL}'pads/175?page='${PAGE1}'&per_page=50' -H 'X-Auth-Email: '${EMAIL}'' -H 'X-Auth-Token: '${TOKEN}'' | jq . | grep 'pad_name'| sed -E 's/"|:|,/ /g' | awk '{print $2}'  >> ./test.txt ; let PAGE1+=1 ; done
do echo > /dev/null 2>&1; curl -sX GET ''{$URL}'pads/175?page='${PAGE1}'&per_page=50' -H 'X-Auth-Email: '${EMAIL}'' -H 'X-Auth-Token: '${TOKEN}'' | jq . | grep 'customer_brand'| sed -E 's/"|:|,/ /g' | awk '{print $2}' >> $dir/padamt.txt  ; let PAGE1+=1 ; done


echo -e "============= 数据处理中 请稍后 =============="
wait

A01_TTL=`grep -E "^A01|^a01" $dir/padamt.txt |wc -l`
A01_percent=`awk 'BEGIN{printf "%.1f%%\n",('$A01_TTL'/'$TTL_AMT')*100}'`
A02_TTL=`grep -E "^A02|^a02|^A86|^a86" $dir/padamt.txt |wc -l`
A02_percent=`awk 'BEGIN{printf "%.1f%%\n",('$A02_TTL'/'$TTL_AMT')*100}'`
A03_TTL=`grep -E "^A03|^a03" $dir/padamt.txt |wc -l`
A03_percent=`awk 'BEGIN{printf "%.1f%%\n",('$A03_TTL'/'$TTL_AMT')*100}'`
A04_TTL=`grep -E "^A04|^a04" $dir/padamt.txt |wc -l`
A04_percent=`awk 'BEGIN{printf "%.1f%%\n",('$A04_TTL'/'$TTL_AMT')*100}'`
A05_TTL=`grep -E "^A05|^a05" $dir/padamt.txt |wc -l`
A05_percent=`awk 'BEGIN{printf "%.1f%%\n",('$A05_TTL'/'$TTL_AMT')*100}'`
A06_TTL=`grep -E "^A06|^a06" $dir/padamt.txt |wc -l`
A06_percent=`awk 'BEGIN{printf "%.1f%%\n",('$A06_TTL'/'$TTL_AMT')*100}'`
B01_TTL=`grep -E "^B01|^b01" $dir/padamt.txt |wc -l`
B01_percent=`awk 'BEGIN{printf "%.1f%%\n",('$B01_TTL'/'$TTL_AMT')*100}'`
C01_TTL=`grep -E "^C01|^c01" $dir/padamt.txt |wc -l`
C01_percent=`awk 'BEGIN{printf "%.1f%%\n",('$C01_TTL'/'$TTL_AMT')*100}'`
C02_TTL=`grep -E "^C02|^c02" $dir/padamt.txt |wc -l`
C02_percent=`awk 'BEGIN{printf "%.1f%%\n",('$C02_TTL'/'$TTL_AMT')*100}'`
C07_TTL=`grep -E "^C07|^c07" $dir/padamt.txt |wc -l`
C07_percent=`awk 'BEGIN{printf "%.1f%%\n",('$C07_TTL'/'$TTL_AMT')*100}'`
AS_TTL=`grep -E "^AS|^as" $dir/padamt.txt |wc -l`
AS_percent=`awk 'BEGIN{printf "%.1f%%\n",('$AS_TTL'/'$TTL_AMT')*100}'`
PAY_TTL=`grep -E "^PAY|^pay" $dir/padamt.txt |wc -l`
PAY_percent=`awk 'BEGIN{printf "%.1f%%\n",('$PAY_TTL'/'$TTL_AMT')*100}'`
AG_TTL=`grep -E "^AG|^agqj" $dir/padamt.txt |wc -l`
AG_percent=`awk 'BEGIN{printf "%.1f%%\n",('$AG_TTL'/'$TTL_AMT')*100}'`
PUB_TTL=`grep -E '^PUB|^public' $dir/padamt.txt |wc -l`
PUB_percent=`awk 'BEGIN{printf "%.1f%%\n",('$PUB_TTL'/'$TTL_AMT')*100}'`
MKT1_TTL=`grep -E '^MKT|^MKT1' $dir/padamt.txt |wc -l`
MKT1_percent=`awk 'BEGIN{printf "%.1f%%\n",('$MKT1_TTL'/'$TTL_AMT')*100}'`
MKT2_TTL=`grep -E '^MKT2|^market2' $dir/padamt.txt |wc -l`
MKT2_percent=`awk 'BEGIN{printf "%.1f%%\n",('$MKT2_TTL'/'$TTL_AMT')*100}'`
MKT3_TTL=`grep -E '^MKT3|^market3' $dir/padamt.txt |wc -l`
MKT3_percent=`awk 'BEGIN{printf "%.1f%%\n",('$MKT3_TTL'/'$TTL_AMT')*100}'`
OTHER_TTL=`egrep -v  '^A0[1-6]|^a0[1-6]|^A86|^B0[1-7]|^b0[1-7]|^C0[1-7]|^c0[1-7]|^AS|^as|^AG|^PAY|^PUB|^MKT|^MKT[1-3]' $dir/padamt.txt |wc -l`
OTHER_percent=`awk 'BEGIN{printf "%.1f%%\n",('$OTHER_TTL'/'$TTL_AMT')*100}'`

#===== Data_Processing =====

echo "=========== 非常感谢您的使用,谢谢 ============="
echo ""

echo Name DomainCount Percent > $dir/result.txt
echo A01 $A01_TTL $A01_percent >> $dir/result.txt
echo A02 $A02_TTL $A02_percent >> $dir/result.txt
echo A03 $A03_TTL $A03_percent >> $dir/result.txt
echo A04 $A04_TTL $A04_percent >> $dir/result.txt
echo A05 $A05_TTL $A05_percent >> $dir/result.txt
echo A06 $A06_TTL $A06_percent >> $dir/result.txt
echo B01 $B01_TTL $B01_percent >> $dir/result.txt
echo C01 $C01_TTL $C01_percent >> $dir/result.txt
echo C02 $C02_TTL $C02_percent >> $dir/result.txt
echo C07 $C07_TTL $C07_percent >> $dir/result.txt
echo AS $AS_TTL $AS_percent >> $dir/result.txt
echo AG $AG_TTL $AG_percent >> $dir/result.txt
echo Pay $PAY_TTL $PAY_percent >> $dir/result.txt
echo Public $PUB_TTL $PUB_percent >> $dir/result.txt
#echo Market_1 $MKT1_TTL $MKT1_percent >> ./result.txt
echo Market_2 $MKT2_TTL $MKT2_percent >> $dir/result.txt
#echo Market_3 $MKT3_TTL $MKT3_percent >> ./result.txt
echo Others $OTHER_TTL $OTHER_percent >> $dir/result.txt

file="$dir/result.txt"

while read line
do
    printf "%10s%15s%15s\n" ${line}

done < ${file} >> $dir/final.txt

#===== Output_Results =====
clear

echo -e "============= $monthly ==============" 
echo ""
cat $dir/final.txt
echo ""
echo -e "=============== 本月 Toffs 额度清单 ===============" 
