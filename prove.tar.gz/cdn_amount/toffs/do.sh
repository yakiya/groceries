/usr/bin/sz $1
