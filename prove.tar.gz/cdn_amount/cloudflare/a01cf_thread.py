#!/usr/bin/env python3
import os
import sys
import json
import requests
import traceback
import threading
import multiprocessing
import math
import selectors

class Mod(object):

    def __init__(self, email, key, url, per_page=50):
        self.email = email
        self.key = key
        self.url = url
        self.per_page = per_page
        self.result = []

    def req_header(self):
        return {
            'X-Auth-Email': self.email,
            'X-Auth-Key': self.key,
            'Content-Type': 'application/json',
        }

    def _get_total_count(self, data):
        response = requests.get(self.url, params=data, headers=self.req_header())
        result = json.loads(response.text)
        return result['result_info']['total_count']

    def _get_data(self, data):
        response = requests.get(self.url, params=data, headers=self.req_header())
        result = json.loads(response.text)
        return [domain['hostname'] for domain in result['result']]
    
    def run(self):
        pool = multiprocessing.Pool(processes=40)
        request_data = {}
        request_data['page'] = 1
        request_data['per_page'] = 1
        total_count = self._get_total_count(request_data)
        page = math.ceil(total_count / self.per_page)
        job_list = []
        for page_num in range(1, page + 1):
            request_data['page'] = page_num
            request_data['per_page'] = self.per_page
            res = pool.apply_async(self._get_data, args=(request_data,))
            job_list.append(res)
        pool.close()
        pool.join()
        
        for res in job_list:
            print(res.get())


if __name__ == '__main__':
    product = Mod('b4@iv66.net', '26faf1934363a706cda8ad647ad24abfdd3e8',
                  'https://api.cloudflare.com/client/v4/zones/be1690944e0091bcf68fce63c8de798c/custom_hostnames')
    product.run()
