#!/bin/bash
#Project: Cloudflare Monthly used v1.2
#auther: Xavi

#===== 固定参数 =====
monthly=`date "+%Y-%m-%d %H:%M:%S"`
TTL_AMT=9000
py_dir='/root/jenkins/walker/shell/cdn_amount/cloudflare'
dir='./files'

#===== File_Init =====
mkdir -p ./files
> $dir/result.txt
> $dir/final.txt
> $dir/a01.txt
> $dir/a02.txt
> $dir/a03txt
> $dir/a04.txt
> $dir/a05.txt
> $dir/a06.txt
> $dir/b01.txt
> $dir/b07.txt
> $dir/c01.txt
> $dir/c07.txt
> $dir/live.txt
> $dir/pay.txt
> $dir/ag.txt
> $dir/public.txt

#===== Get_Custom_hostnames =====
clear
echo "=========== Get Custom_hostnames, wait ============="

$py_dir/a01cf.py > $dir/a01.txt &
$py_dir/a02cf.py > $dir/a02.txt &
$py_dir/a03cf.py > $dir/a03.txt &
$py_dir/a04cf.py > $dir/a04.txt &
$py_dir/a05cf.py > $dir/a05.txt &
$py_dir/a06cf.py > $dir/a06.txt &
$py_dir/a06cf.py > $dir/a06.txt &
$py_dir/b01cf.py > $dir/b01.txt &
$py_dir/b07cf.py > $dir/b07.txt &
$py_dir/c01cf.py > $dir/c01.txt &
$py_dir/c07cf.py > $dir/c07.txt &
$py_dir/payback.py > $dir/pay.txt &
$py_dir/payback2.py >> $dir/pay.txt
$py_dir/800.py > $dir/live.txt &
$py_dir/ag.py > $dir/ag.txt &
$py_dir/ag2.py >> $dir/ag.txt 
$py_dir/public.py > $dir/public.txt &
wait

a01_TTL=`sort -u $dir/a01.txt | uniq | wc -l`
a01_percent=`awk 'BEGIN{printf "%.1f%%\n",('$a01_TTL'/'$TTL_AMT')*100}'`

a02_TTL=`sort -u $dir/a02.txt | uniq | wc -l`
a02_percent=`awk 'BEGIN{printf "%.1f%%\n",('$a02_TTL'/'$TTL_AMT')*100}'`

a03_TTL=`sort -u $dir/a03.txt | uniq | wc -l`
a03_percent=`awk 'BEGIN{printf "%.1f%%\n",('$a03_TTL'/'$TTL_AMT')*100}'`

a04_TTL=`sort -u $dir/a04.txt | uniq | wc -l`
a04_percent=`awk 'BEGIN{printf "%.1f%%\n",('$a04_TTL'/'$TTL_AMT')*100}'`

a05_TTL=`sort -u $dir/a05.txt | uniq | wc -l`
a05_percent=`awk 'BEGIN{printf "%.1f%%\n",('$a05_TTL'/'$TTL_AMT')*100}'`

a06_TTL=`sort -u $dir/a06.txt | uniq | wc -l`
a06_percent=`awk 'BEGIN{printf "%.1f%%\n",('$a06_TTL'/'$TTL_AMT')*100}'`

b01_TTL=`sort -u $dir/b01.txt | uniq | wc -l`
b01_percent=`awk 'BEGIN{printf "%.1f%%\n",('$b01_TTL'/'$TTL_AMT')*100}'`

b07_TTL=`sort -u $dir/b07.txt | uniq | wc -l`
b07_percent=`awk 'BEGIN{printf "%.1f%%\n",('$b07_TTL'/'$TTL_AMT')*100}'`

c01_TTL=`sort -u $dir/c01.txt | uniq | wc -l`
c01_percent=`awk 'BEGIN{printf "%.1f%%\n",('$c01_TTL'/'$TTL_AMT')*100}'`

c07_TTL=`sort -u $dir/c07.txt | uniq | wc -l`
c07_percent=`awk 'BEGIN{printf "%.1f%%\n",('$c07_TTL'/'$TTL_AMT')*100}'`

AG_TTL=`sort -u $dir/ag.txt | uniq | wc -l`
AG_percent=`awk 'BEGIN{printf "%.1f%%\n",('$AG_TTL'/'$TTL_AMT')*100}'`

Live_TTL=`sort -u $dir/live.txt | uniq | wc -l`
Live_percent=`awk 'BEGIN{printf "%.1f%%\n",('$Live_TTL'/'$TTL_AMT')*100}'`

Pay_TTL=`sort -u $dir/pay.txt | uniq | wc -l`
Pay_percent=`awk 'BEGIN{printf "%.1f%%\n",('$Pay_TTL'/'$TTL_AMT')*100}'`

Public_TTL=`sort -u $dir/public.txt | uniq | wc -l`
Public_percent=`awk 'BEGIN{printf "%.1f%%\n",('$Public_TTL'/'$TTL_AMT')*100}'`

echo "=========== 非常感谢您的使用,谢谢 ============="
echo ""

echo Name DomainCount Percent > $dir/result.txt
echo a01 $a01_TTL $a01_percent >> $dir/result.txt
echo a02 $a02_TTL $a02_percent >> $dir/result.txt
echo a03 $a03_TTL $a03_percent >> $dir/result.txt
echo a04 $a04_TTL $a04_percent >> $dir/result.txt
echo a05 $a05_TTL $a05_percent >> $dir/result.txt
echo a06 $a06_TTL $a06_percent >> $dir/result.txt
echo b01 $b01_TTL $b01_percent >> $dir/result.txt
echo b07 $b07_TTL $b07_percent >> $dir/result.txt
echo c01 $c01_TTL $c01_percent >> $dir/result.txt
echo c07 $c07_TTL $c07_percent >> $dir/result.txt
echo AG  $AG_TTL  $AG_percent >> $dir/result.txt
echo 800 $Live_TTL $Live_percent >> $dir/result.txt
echo pay $Pay_TTL $Pay_percent >> $dir/result.txt
echo Pub $Public_TTL $Public_percent >> $dir/result.txt

file="$dir/result.txt"

while read line
do
    printf "%10s%15s%15s\n" ${line}

done < ${file} >> $dir/final.txt

#===== Output_Results =====
clear

echo -e "============= $monthly ==============" 
echo ""
cat $dir/final.txt
echo ""
echo -e "=============== 本月 CF 额度清单 ==============="

