#!/usr/bin/env python3
# file: test.py
# auth: walker

"""
changelog:

    2019.06.11 init
"""

import os
import sys
import json
import requests
import traceback

class Mod(object):

    def __init__(self):
        pass

    def run(self):
        url = 'https://api.cloudflare.com/client/v4/zones/afd6265f5d2c3e1699e352e55fb8bbfb/custom_hostnames'
        reqH = {
        'X-Auth-Email': 'b4@iv66.net',
        'X-Auth-Key': '26faf1934363a706cda8ad647ad24abfdd3e8',
        'Content-Type': 'application/json',
        }
        
        reqD = {}
        reqD['page'] = 1
        reqD['per_page'] = 50
        
        domain_list = []
        page = 1
        total = 1
        try:
            rsp = requests.get(url, params=reqD, headers=reqH)
            dict_ = json.loads(rsp.text)
            domain_list += [n['hostname'] for n in dict_['result']]
            total = dict_['result_info']['total_pages']
#            print(total, page)
            page += 1
        except Exception as e:
            err = traceback.format_exc()
            print(err)

        while page <= total:
            try:
                reqD['page'] = page
                rsp = requests.get(url, params=reqD, headers=reqH)
                dict_ = json.loads(rsp.text)
                domain_list += [n['hostname'] for n in dict_['result']]
#                print(total, page)
                page += 1
            except Exception as e:
                err = traceback.format_exc()
                print(err)
            
        for n in domain_list:
            print(n)
        
if __name__ == '__main__':

    os.chdir(sys.path[0])

    mod = Mod()
    mod.run()
